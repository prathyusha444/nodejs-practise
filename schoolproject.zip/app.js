var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const sql = require('mssql')
const session = require("express-session");
const moment = require("moment");
const flash = require("connect-flash");
var bodyParser = require('body-parser');

var path = require('path');

var app = express();


var indexRouter = require('./routes/index');
//var usersRouter = require('./routes/users');
var signupRouter=require('./routes/signup');
var loginRouter=require('./routes/login');
var dashboardRouter=require('./routes/dashboard');
var logoutRouter=require('./routes/logout');
var studentProfileRouter=require('./routes/studentProfile');
var attendanceRouter=require('./routes/attendance');
var contactRouter=require('./routes/contact')
var mainHomeRouter=require('./routes/mainHome');
var studentInfoRouter=require('./routes/studentInfo');
var announcementRouter=require('./routes/announcement')
var aboutRouter=require('./routes/about')
var imageRouter=require('./routes/image')
var addUpdateRouter=require('./routes/schoolUpdates')
var addUserRouter=require('./routes/addUser')
var editUserRouter=require('./routes/editUser')
var viewRouter=require('./routes/view')
var deleteRouter=require('./routes/delete')


app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.set('port', process.env.PORT || 3000);
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(
  session({
    secret:'secretstringforsession',
    resave: true,
    saveUninitialized: true
  })
);
app.use(flash());
app.use((req, res, next) => {
  res.locals.error = req.flash("error");
  res.locals.success = req.flash("success");
  res.locals.moment = moment;
  next();
});


app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use('/index', indexRouter);
//app.use('/', usersRouter);
app.get('/signup',signupRouter);
app.post('/signup',signupRouter);
app.get('/adminsignup',signupRouter);
app.post('/adminsignup',signupRouter);
app.get('/login',loginRouter);
app.post('/login',loginRouter);
app.get('/adminlogin',loginRouter);
app.post('/adminlogin',loginRouter);
app.get('/home/dashboard',dashboardRouter);
app.get('/home/admindashboard',dashboardRouter);
app.get('/home/logout', logoutRouter);
app.get('/home/profile',studentProfileRouter);
app.get('/home/attendance',attendanceRouter);
app.post('/home/updateAttendance',attendanceRouter);
app.post('/studentInfo',studentInfoRouter);
app.get('/studentInfo',studentInfoRouter);
app.get('/',mainHomeRouter);
app.get('/addUser', addUserRouter);
app.post('/addUser', addUserRouter);
app.get('/editUser/:email', editUserRouter);
app.post('/editUser/:email', editUserRouter);
app.get('/delete/:email',deleteRouter);
app.get('/view/:email', viewRouter);
app.get('/announcement',announcementRouter);
app.post('/announcement',announcementRouter);
app.get('/contact',contactRouter);
app.get('/about',aboutRouter);
app.get('/image',imageRouter);
app.get('/schoolUpdates',addUpdateRouter);


// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
