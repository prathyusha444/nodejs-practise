const jwt = require('jsonwebtoken');

const verifyJwtAuth = (token) => {
    return new Promise((resolve, reject) => {
        const secret = 'QWER@#$^';
        jwt.verify(token, secret, function(err, decoded) { // step -5 verifying token
            if (err) {
              reject('Verification Failed');
            } else {2
                console.log(decoded.user) // bar
                if (decoded.foo === 'bar') {
                    console.log('Token verified succesfully');
                    resolve('Verified Successfully');
                }
            }
        });
    })
}

exports.verifyJwtAuth = verifyJwtAuth;