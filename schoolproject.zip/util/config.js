const sql = require('mssql');
const config = {
    server: 'localhost',
    user: "root",
    password: "root",
    database: "project",
    options: {
      //enableArithAbort:true,//
      trustServerCertificate: true
   },
    connectionTimeout: 150000,
    pool: {
      max: 10,
      min: 0,
      idleTimeoutMillis: 30000
    },
  };
  sql.on("error", err => {
    console.log(error)
  })
  module.exports=config