var express = require('express');
var router = express.Router();
const moment = require("moment");
const config = require('../util/config');
const sql = require('mssql');
const verifyJwtAuth = require("../util/verifyJwtAuth");
const jwt = require('jsonwebtoken');



router.get('/addUser', (req, res) => {
    
            res.render('addUser');
    

});
router.post("/addUser", async (req, res, next) => {
    const dateTimeFormatUpdate = 'YYYY-MM-DD HH:mm:ss';
    const time = moment.utc().format(dateTimeFormatUpdate);
    const datesObj = new Date();
    const b = datesObj.toISOString();
    console.log(b)     
 
    try {
       let pool = await sql.connect(config)
       let results= await pool.request()
       .input('class', sql.Int, req.body.class)
       .input('section', sql.VarChar(50), req.body.section)
      .input('first_name', sql.VarChar(50), req.body.first_name)
          .input('last_name', sql.VarChar(50), req.body.last_name)
          .input('email', sql.NVarChar(255), req.body.email)
          .input('gender', sql.VarChar(50), req.body.gender)
          .input('age', sql.Int, req.body.age)
          .input('bio', sql.VarChar(50), req.body.bio)
          .input('DateOfAdmission', sql.Date, b)
          .input('password', sql.VarChar(50), req.body.password)
       .query(`INSERT INTO student(class, section,first_name,last_name,email,gender,age,bio,DateOfAdmission,password)
        VALUES(@class, @section ,@first_name ,@last_name,@email,@gender,@age,@bio,'${b}',@password)`)
 
        const email=req.body.email
       let result1 = await pool.request()
          .input('email', sql.NVarChar(50), req.body.email)
          .input('attendancecount', sql.Int, req.body.attendancecount)
          .input('lastUpdatedTime', sql.DateTime, time)
          .input('presentDates', sql.Date, req.body.presentDates)
          .query(`INSERT INTO attendance(email,attendancecount,lastUpdatedTime,presentDates) VALUES (@email,0,'${time}','${b}')`)
  let result= await pool.request()
                .query(`select * from student where email= '${email}'`);
            res.redirect("/addUser");
          } catch (e) {
             console.log(e);
          }
       })
       module.exports = router;