var express = require('express');
var router = express.Router();
const moment = require("moment");
const config = require('../util/config');
const sql = require('mssql');
const verifyJwtAuth = require("../util/verifyJwtAuth");
const jwt = require('jsonwebtoken');



router.get('/studentInfo', (req, res) => {
    verifyJwtAuth.verifyJwtAuth(req.cookies.info.code).then((result) => {
        if (result === 'Verified Successfully') {
            const email = req.cookies.info.email
            console.log(email);
            sql.connect(config).then(pool => {

                return pool.request()
                    .query('select * from student ')


            }).then(result => {
                //console.log(result)
                res.render('studentInfo', { results: result.recordset });
            })
        }
    })
});
sql.on("error", err => {
    console.log(error)
})


router.post('/studentInfo', (req, res) => {
    verifyJwtAuth.verifyJwtAuth(req.cookies.info.code).then((result) => {
        if (result === 'Verified Successfully') {
            const email = req.cookies.info.email
            console.log(email);
            sql.connect(config).then(pool => {
                let searchTerm = req.body.search;
                console.log("Printing", req.body)
                console.log(searchTerm)
                return pool.request()
                    //.input('name', sql.VarChar, value)
                    //.query(`select * from student WHERE id LIKE ?`,['%' + searchTerm + '%'])
                    .query(`select * from student WHERE first_name LIKE '%${searchTerm}%'`)
            }).then(result => {
                console.log(result)

                res.render('studentInfo', { results: result.recordset });


            });
        }
    })

    
   



    
});



module.exports = router;

