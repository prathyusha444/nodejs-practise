
var express = require('express');
var router = express.Router();
const moment = require("moment");
const config = require('../util/config');
const sql = require('mssql');
const verifyJwtAuth= require("../util/verifyJwtAuth");
const jwt = require('jsonwebtoken');

router.get('/home/profile', (req, res) => {
   
    (async function () {
       try {
         verifyJwtAuth.verifyJwtAuth(req.cookies.info.code).then(async(result) => {
            if (result === 'Verified Successfully') {
               const email = req.cookies.info.email
               console.log(email);

          let pool = await sql.connect(config)
          let result1 = await pool.request()
             //.input('id', sql.Int, req.params.id)
             .input('email', sql.NVarChar(50), req.params.email)
 
             .query(`SELECT * FROM student where email='${email}'`)
           console.log('result1',result1)
          res.render('profile', { data: result1.recordset[0] });
       }
       })
       } catch (err) {
          console.log(err)
 
       }
    })()
 
    sql.on('error', err => {
       console.log(err);
    })
 })
 module.exports = router;
