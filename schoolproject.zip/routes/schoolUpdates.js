
var express = require("express");
var router = express.Router();
const config = require('../util/config');
const sql = require('mssql');



router.get("/schoolUpdates", function (req, res, next) {
 
  const announcement = req.params.announcementmsg ;
    (async function () {
      try {
        
    let pool = await sql.connect(config)
    let users = await pool.request()
    
    
     .input('announcementmsg', sql.NVarChar(50), req.params.announcementmsg)
   .query(`select * from  schoolupdates `)
   console.log('announcement',announcement)
  
   res.render('schoolUpdates',{ data:users.recordset });

  
   // console.log(admin)
  } catch (err) {
    
    console.log(err)
  }
    })()
 

});


module.exports = router;
