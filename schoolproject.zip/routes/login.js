

var express = require('express');
var router = express.Router();
const moment = require("moment");
const config = require('../util/config');
const sql = require('mssql');
const verifyJwtAuth = require("../util/verifyJwtAuth");
const jwt = require('jsonwebtoken');

//-----------------------------------------------login page call------------------------------------------------------
router.get('/login', (req, res) => {
    const message = "";
    res.render('index', { message: message });
 })
 
 
 router.post('/login', (req, res) => {
   const secret = 'QWER@#$^';
    const message = '';
    (async function () {
       try {
        const email = req.body.email;
        const password = req.body.password;
          let pool = await sql.connect(config)
          let result = await pool.request()
             .input('email', sql.NVarChar(50), req.body.email)
             .input('password', sql.VarChar(50), req.body.password)
             .query("SELECT * FROM student where email=@email")
             console.log('email',result)
             if (result.recordset[0].length !== 0) {
                if ((result.recordset[0].email === email) && (result.recordset[0].password === password)) {
                 console.log("matched");
                 try {
                  const token = jwt.sign({ foo: 'bar' }, secret, { algorithm: 'HS256' }); 
                          const info = {
                              email: result.recordset[0].email,
                              code: token,
                              role: 'student'
                          }
                          res.cookie('info', info);
                          console.log('verify email',result.recordset[0].email)
                 res.redirect(`/home/dashboard`);
               }catch(err) {
                  console.log(err)
              }
                }
                
            }
            
            } catch (err) {
          const message = 'Wrong Credentials.'
          console.log(err)
          res.render('index', { message: message });
 
       }
    })()
 
    sql.on('error', err => {
       console.log(err);
       // res.render('index', { message: message });
    })
 })



 
 //-----------------------------------------------adminlogin page call------------------------------------------------------
 router.get('/adminlogin', (req, res) => {
     const message = "";
     res.render('adminindex', { message: message });
  })
  
  
  router.post('/adminlogin', (req, res) => {
   const secret = 'QWER@#$^';
     const message = '';
     (async function () {
        try {
            const email = req.body.email;
            const password = req.body.password;
               let pool = await sql.connect(config)
               let results = await pool.request()
                 .input('email', sql.NVarChar(50), req.body.email)
                 .input('password', sql.VarChar(50), req.body.password)
                 .query(`select * from admin `)
              if (results.recordset[0].length !== 0) {
                 if ((results.recordset[0].email === email) && (results.recordset[0].password === password)) {
                  console.log("matched");
                  const token = jwt.sign({ foo: 'bar' }, secret, { algorithm: 'HS256' }); 
                  const info = {
                      email: results.recordset[0].email,
                      code: token,
                      role: 'admin'
                  }
                  res.cookie('info', info);
                  console.log('verify email',results.recordset[0].email)
                  res.redirect(`/home/admindashboard`);
                 }
 
             }
             } catch (err) {
           const message = 'Wrong Credentials.'
           console.log(err)
           res.render('adminindex', { message: message });
  
        }
     })()
  
     sql.on('error', err => {
        console.log(err);
        // res.render('index', { message: message });
     })
  })
 
 module.exports = router; 