
var express = require('express');
var router = express.Router();
const moment = require("moment");
const config = require('../util/config');
const sql = require('mssql');
const verifyJwtAuth= require("../util/verifyJwtAuth");
const jwt = require('jsonwebtoken');
    router.get('/delete/:email', function (req, res, next) {
        sql.connect(config, function (err) {
            if (err)
                console.log(err);
                const email=req.params.email

            var request = new sql.Request();
            request
               
                .input('email', sql.NVarChar(50), req.params.email)
                
                .query(`DELETE FROM student WHERE email='${email}' `, function (err, result) {
                    if (err) {
                        console.log(err);
                        res.send(err);

                    }

                    sql.close();
                    res.redirect('/studentInfo');
                });
        });
    });
    module.exports = router;