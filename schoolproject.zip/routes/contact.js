var express = require('express');
var router = express.Router();
const config = require('../util/config');
const sql = require('mssql');
const verifyJwtAuth = require("../util/verifyJwtAuth");
const jwt = require('jsonwebtoken');
router.get('/contact', function(req, res, next) {
  try{
    verifyJwtAuth(req.cookies.info.code).then((result)=>{
      if (result === 'Verified Successfully'){
        res.render('contact', { title: 'Express' });
      }else{
        res.send('<h3>login please</h3>')
      }
    })
  }catch(err){
    console.log('incorrect token' );
    res.send('<h3>login please</h3>')
  }

 
});
module.exports = router;