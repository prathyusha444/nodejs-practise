
var express = require('express');
var router = express.Router();
const moment = require("moment");
const config = require('../util/config');
const sql = require('mssql');
const verifyJwtAuth = require("../util/verifyJwtAuth");
const jwt = require('jsonwebtoken');

router.get('/editUser/:email', function (req, res, next) {
        
        
    sql.connect(config, function (err) {
        if (err)
            console.log(err);
          const email=req.params.email
        var request = new sql.Request();
        request
            .input('email', sql.NVarChar(50), req.params.email)
            .query(`SELECT * FROM student where email='${email}' `, function (err, result) {
                console.log(result.recordset[0])
                if (err) {
                    console.log(err);
                    res.send(err);

                }

                sql.close();
                res.render('editUser', { results: result.recordset[0] });
            });
    });
});

router.post('/editUser/:email', function (req, res, next) {
    sql.connect(config, function (err) {
        if (err)
            console.log(err);

        console.log('body for edit : ', req.body);
        const email=req.body.email
        const request = new sql.Request();
        request
            .input('class', sql.Int, req.body.class)
            .input('section', sql.VarChar(50), req.body.section)
            .input('first_name', sql.VarChar(50), req.body.first_name)
            .input('last_name', sql.VarChar(50), req.body.last_name)
            .input('email', sql.NVarChar(50), req.body.email)
            .input('gender', sql.VarChar(50), req.body.gender)
            .input('age', sql.Int, req.body.age)
            .input('bio', sql.VarChar(50), req.body.bio)
            //.input('DateOfAdmission', sql.Date, b)
            .input('password', sql.VarChar(50), req.body.password)

            .query(`UPDATE student SET first_name=@first_name,age=@age where email='${email}'`, function (err, result) {

                if (err) {
                    console.log(err);
                    res.send(err);
                }
                sql.close();
                res.redirect('/studentInfo');

            });
    });
});
module.exports = router;