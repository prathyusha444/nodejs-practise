

var express = require('express');
var router = express.Router();
const moment = require("moment");
const config = require('../util/config');
const sql = require('mssql');
const verifyJwtAuth = require("../util/verifyJwtAuth");
const jwt = require('jsonwebtoken');

router.get('/home/dashboard', (req, res) => {
   (async function () {
try {
        verifyJwtAuth.verifyJwtAuth(req.cookies.info.code).then(async(result) => {
            if (result === 'Verified Successfully') {
               const email = req.cookies.info.email
               console.log(email);
               let pool = await sql.connect(config)
               let result1 = await pool.request()
                  .input('email', sql.NVarChar(50), req.params.email)
                  .query("SELECT * FROM student ")

               console.log('in dashboard', result1)
               console.log(req.params.email)
               res.render('dashboard', { result1: result1.recordset[0] });

            }
         })

      } catch (err) {
         console.log(err)

      }
   })()

   sql.on('error', err => {
      console.log(err);
   })
})


//------------------------------------//admindashboard//------------------------------------------------------

router.get('/home/admindashboard', (req, res) => {

   (async function () {
      try {
         verifyJwtAuth.verifyJwtAuth(req.cookies.info.code).then(async(result) => {
            if (result === 'Verified Successfully') {
               const email = req.cookies.info.email
               console.log(email);
         let pool = await sql.connect(config)
         let result1 = await pool.request()
            .input('email', sql.NVarChar(50), req.params.email)
            .query("SELECT * FROM admin")

         console.log('in dashboard', result1)
         console.log(req.params.email)
         res.render('admindashboard', { result1: result1.recordset[0] });
            }
         })


      } catch (err) {
         console.log(err)

      }
   })()

   sql.on('error', err => {
      console.log(err);
   })
})



module.exports = router;
