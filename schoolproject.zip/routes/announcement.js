
var express = require("express");
var router = express.Router();
const config = require('../util/config');
const sql = require('mssql');
const verifyJwtAuth = require("../util/verifyJwtAuth");
const jwt = require('jsonwebtoken');


router.get("/announcement", function (req, res, next) {
  try{
    verifyJwtAuth.verifyJwtAuth(req.cookies.info.code).then((result)=>{
    if (result === 'Verified Successfully'){
      const email = req.cookies.info.email
      console.log(email);
      res.render("announcement");
    }
  })
}catch(err){
  console.log('incorrect token' );
  res.send('<h3>login please</h3>')
}
  })

      

router.post('/announcement',(req,res,next)=>{
  (async function () {
    try {
      verifyJwtAuth.verifyJwtAuth(req.cookies.info.code).then(async(result) => {
        if (result === 'Verified Successfully') {
           const email = req.cookies.info.email
           console.log(email);
  let pool = await sql.connect(config)
  let users = await pool.request()
  
 
   .input('announcementmsg', sql.NVarChar(50), req.body.announcementmsg)
 .query(`INSERT INTO schoolupdates(announcementmsg) VALUES(@announcementmsg)`)
  res.render('announcement');
  console.log(users);
        }
      })
 // console.log(admin)
} catch (err) {
  
  console.log(err)
}
  })()
})
  

module.exports = router;