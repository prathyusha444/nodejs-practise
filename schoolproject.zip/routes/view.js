
var express = require('express');
var router = express.Router();
const moment = require("moment");
const config = require('../util/config');
const sql = require('mssql');
const verifyJwtAuth= require("../util/verifyJwtAuth");
const jwt = require('jsonwebtoken');

router.get('/view/:email', (req, res) => {
   
    (async function () {
       try {
        
        const email=req.params.email
          let pool = await sql.connect(config)
          let results = await pool.request()
             //.input('id', sql.Int, req.params.id)
             .input('email', sql.NVarChar(50), req.params.email)
 
             .query(`SELECT * FROM student where email='${email}'`)
           console.log('results',results)
          res.render('view', { data: results.recordset[0] });
      
       } catch (err) {
          console.log(err)
 
       }
    })()
 
    sql.on('error', err => {
       console.log(err);
    })
 })
 module.exports = router;