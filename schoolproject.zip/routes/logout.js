
var express = require('express');
var router = express.Router();
const moment = require("moment");
const config = require('../util/config');
const sql = require('mssql');
const verifyJwtAuth= require("../util/verifyJwtAuth");
const jwt = require('jsonwebtoken');



router.get('/home/logout', (req, res) => {
    res.clearCookie('jwtToken')
    res.redirect("/login");
 })
 
module.exports = router;
