create table employee
(
id int,
name varchar(30),
age int,
gender varchar(30),
salary int
)

insert into employee
values(1,'sai',19,'male',12000),(2,'rama',21,'female',9000),(3,'ram',19,'male',9500),(4,'satya',21,'female',10000),
(5,'dolly',22,'female',11000),(6,'neha',19,'female',12345),(7,'yamini',22,'female',12111),(8,'amar',19,'male',8000),(9,'lin',22,'male',8356),
(10,'sam',21,'male',8567)
/*subquery*/
select * 
from employee
where gender='male' 
and
salary>
(select avg(salary) avg_salary
from employee
where gender='female')
/*corelated subquery*/
select salary as nth_highest_salary
from employee as e1
where 
1=(select count(*) from employee as e2
where e1.salary<e2.salary)

select salary as nth_highest_salary
from employee as e1
where 
0=(select count(*) from employee as e2
where e1.salary<e2.salary)


select salary as nth_lowest_salary
from employee as e1
where 
0=(select count(*) from employee as e2
where e1.salary>e2.salary)

