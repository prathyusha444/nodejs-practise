create table student
(
id int,
name varchar(30),
age int,
sports varchar(30),
marks int,
rank int
)

insert into student
values(1,'sai',19,'coco',89,1),(2,'ram',21,'cricket',85,2),(3,'gopi',19,'kabbadi',75,9),(4,'tom',21,'coco',78,8),
(5,'dooly',22,'cricket',81,6),(6,'neha',19,'coco',79,7),(7,'satya',22,'kabaddi',84,4),(8,'amar',19,'cricket',70,10),(9,'lin',22,'coco',83,5),
(10,'sam',21,'cricket',85,2)

select name,age,marks 
from student
order by marks desc,age desc,name desc  

select sports from student
group by sports
select sports,count(name)no_of_students from student
group by sports,name


select sports,avg(marks)avg_marks from student
group by sports,name

 select sports,count(name)no_of_students,
 avg(marks)avg_marks
 from student
group by sports,marks
having  marks>65
