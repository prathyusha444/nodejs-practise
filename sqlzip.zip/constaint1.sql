/*to find unique notnull name and gmail with age >16 */
create table student
(
id int,
name varchar(30) not null,
gmail varchar(30) not null,
age int,
primary key(id),
unique(gmail),
check(age>16)
)


