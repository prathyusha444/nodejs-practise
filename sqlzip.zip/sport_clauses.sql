select * from student 
union
select * from student
where sports='cricket'

select * from student 
intersect
select * from student
where sports='cricket'