create index salary_index on
employee(salary asc)

