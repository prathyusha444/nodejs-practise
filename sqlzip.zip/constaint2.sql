insert into student
(id,name,gmail,age)
values
(1,'ram','ram@gmail.com',18),
(2,'sai','sai@gmail.com',19),
(3,'gopal','gopi@gmail.com',17)