insert into 
student 
values(1,'sai',60,21),(2,'ram',65,22),(3,'roy',56,22),(4,'anil',75,21),(5,'raj',71,22),(6,'raju',60,21),(7,'gopi',55,22),(8,'nag',45,21)

