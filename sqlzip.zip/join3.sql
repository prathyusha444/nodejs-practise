select * from
student as t1
inner join
marks as t2
on
t1.id=t2.id
select * from
student as t1
left join
sports t2
on
t1.id=t2.id
select * from
ncc_nss as t1
right join
student t2
on
t1.id=t2.id
select * from
ncc_nss as t1
full outer join
sports t2
on
t1.id=t2.id
select * from
student as t1
inner join
student as t2
on
t1.age<t2.age
