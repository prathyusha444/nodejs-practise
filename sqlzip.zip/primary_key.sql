create table p1(
e_id int primary key,
ename varchar(40),
salary money
)
insert into p1 
values(10,'sai',23000),(20,'ram',21000),(30,'james',20000)
SELECT * FROM P1

create table c1(
mbno bigint,
eadd varchar(30),
e_id int ,
foreign key(e_id) references p1(e_id)
on update cascade on delete cascade)


insert into c1
values(9849114404,'hyd',10),(9737564712,'mumbai',10),(3089675645,'mp',20),(9736457811,'ap',30)


select * from p1
select * from c1
update p1 set e_id=1 where e_id=30
delete from p1 where e_id=1