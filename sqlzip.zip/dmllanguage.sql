CREATE TABLE student(
student_id int,
student_name varchar(40),
student_age int,
student_avg decimal(10,2),
student_parent varchar(30))
/*INSERT TO PERTICULAR COLUMN*/

insert into 
student(student_id,student_name,student_age)
values(1,'sai',21),(2,'ram',24),(3,'raj',22);
/*insert to all columns*/
insert into
student values(4,'pallavi',21,86,'rao'),(5,'roy',20,85,'kumar');


UPDATE student 
set student_avg=75
where student_avg is NULL

delete from student
where student_avg>85