create table student
(
id int,
name varchar(30),
age int
);
create table marks
(
id int,
marks int,
rank int
);
create table sports
(
id int,
sports varchar(30),
);
create table ncc_nss
(
id int,
ncc_nss varchar(30)
);
truncate table student
