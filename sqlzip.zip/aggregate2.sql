create table student
(
id int,
name varchar(20),
marks int,
age int
);