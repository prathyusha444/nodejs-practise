
insert into
studentdetails
values
(1,'sai','mail1@gmail.com'),(2,'ram','mail2@gmail.com'),(3,'ammu','mail3@gmail.com');