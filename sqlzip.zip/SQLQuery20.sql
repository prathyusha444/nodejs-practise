create table studentdetails(
id int,
name varchar(30),
gmail varchar(30),
primary key(id)
)

create table certificate
(
id int ,
year int,
sem int,
primary key(id)
)
