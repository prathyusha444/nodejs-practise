create view my_view as 
select id,name,age from employee
where gender= 'male'

