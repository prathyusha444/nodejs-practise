select count(*) from student
where age=21
select max(marks) from student
where age=21
select min(marks) from student
where age=21
select sum(marks) from student
where age in(21,22)
select avg(marks) from student
where age=21
select * from student
where name like '%a%'
select avg(marks) from student
where age<>21
select distinct(age) from student
select max(distinct age) from student

select avg(distinct age) from student


