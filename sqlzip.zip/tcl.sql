create table bank (
id int,
bname varchar(40),
blocation varchar(40)
)
 begin Transaction
 insert into bank values(1,'sbi','hyd'),(2,'sbi','vij')
 begin Transaction
 RollBack
 select * from bank

 begin Transaction
 insert into bank values(1,'sbi','hyd'),(2,'sbi','vij')
 commit

 
 begin Transaction
 update bank set blocation='mumbai'
 where id=1
 commit

 begin Transaction
 delete bank 
 where id=1
  begin Transaction
  rollback

  begin Transaction
  delete from bank
  where id=1
  save Transaction s1
   delete from bank
  where id=2
  begin Transaction
  rollback Transaction s1