select rank() over(order by marks desc) as
rank,
id,
marks
from marks
select row_number() over(order by marks desc) as
rank,
id,
marks
from marks
select dense_rank() over(order by marks desc) as
rank,
id,
marks
from marks