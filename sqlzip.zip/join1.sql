insert into student
values(1,'sai',19),(2,'ram',21),(3,'gopi',19),(4,'tom',21),(5,'dooly',22),(6,'neha',19),(7,'satya',22),(8,'amar',19),(9,'lin',22),(10,'sam',21)
insert into marks
values(1,89,1),(2,85,2),(3,75,9),(4,78,8),(5,81,6),(6,79,7),(7,84,4),(8,70,10),(9,83,5),(10,85,2)
 insert into sports
values(1,'coco'),(3,'kabbadi'),(4,'coco'),(6,'coco'),(7,'kabbadi'),(9,'coco')
insert into ncc_nss
values(2,'ncc'),(3,'nss'),(4,'ncc'),(8,'nss'),(9,'nss')