{
    let x = 5;
let z = x ** 2; 
console.log(z);}
{
let x = 5;
let z = Math.pow(x,2);//math.pow and x**2 are same//
console.log(z);}