let text1 = "Hello World!";       // String
console.log(text1.toLowerCase());
