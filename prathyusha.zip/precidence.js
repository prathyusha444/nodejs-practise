let x = 100 + 50 * 3;// '*' has first precendence//
console.log(x);
let y = (100 + 50) * 3;
console.log(y);//braces have first precedence//