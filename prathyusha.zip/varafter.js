console.log( "carName");
var carName = "volvo";//var can be before or after the console//
            