let x = 5 + 5;
console.log(x);
let y = "5" + 5;
console.log(y);
console.log( z = "Hello" + 5);
