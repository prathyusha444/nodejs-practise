let str = "Apple, Banana, Kiwi";
console.log(part = str.substr(7, 6));
//2 parameter defines length of string//

{let str = "Apple, Banana, Kiwi";
console.log(part = str.substr(-4));}


let text = "Please visit Microsoft!";
console.log( newText = text.replace("Microsoft", "W3Schools"));
