let x = 5;
x++;
console.log( z = x);