
            const cars = {type:"fiat",model:"500",color:"white"};
            cars.color="red";
            cars.owner="johnson";
          console.log( "cars owner is"+cars.owner);