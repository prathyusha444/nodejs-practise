{let x = 10;
console.log(x += 5);}
{let x = 10;
console.log(x /= 5);}
