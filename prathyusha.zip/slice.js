let str = "Apple, Banana, Kiwi";
console.log( part = str.slice(7, 13));

{let str = "Apple, Banana, Kiwi";
console.log( part = str.slice(-12, -6));}
//string reans from end to begin when we use'-'// 


{let str = "Apple, Banana, Kiwi";
console.log(part = str.slice(-12));}
//if no second parameter given program runs upto end of the sting//
