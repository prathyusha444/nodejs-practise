let a = 3;
let x = (100 + 50) * a;
console.log(x);
