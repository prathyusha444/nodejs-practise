 var cars = ["saab","volvo","bmw"];
cars[0]="toyota";
 console.log(cars[0]);
            