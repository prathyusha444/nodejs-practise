// camelCase

console.log('Hello World');