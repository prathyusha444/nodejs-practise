
            let x=10;
            {
                let x=2;
                //here x is 2
            }
            //here x is10
    console.log(x) ;
            